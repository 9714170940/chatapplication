  let chat = document.querySelector(".chat");
  let adding = document.createElement('div');
  adding.className = "addChat";
  adding.id = "addchat";

function openchat(){
  adding.innerHTML =`<div class="join-container">
  <header class="join-header">
    <h1><i class="fas fa-smile"></i> ChatApp</h1>
  </header>
  <main class="join-main">
    <form action="chat.html">
      <div class="form-control">
        <label for="username">Client:</label>
        <input
          type="text"
          name="username"
          id="username"
          placeholder="Enter your name..."
          required
        />
      </div>
      <div class="form-control">
        <label for="room">Room</label>
        <select name="room" id="room">
          <option value="JavaScript">Room 1</option>
          <option value="Python">Room 2</option>
          <option value="PHP">Room 3</option>
          <option value="C#">Room 4</option>
          <option value="Ruby">Room 5</option>
          <option value="Java">Room 6</option>
        </select>
      </div>
      <button type="submit" class="btn">Enter Room</button>
    </form>
  </main>
</div>`;
      
 chat.append(adding);  
}